<?php
include("../../common/common.php");
class Center{
  
    // database connection and table name
    private $conn;
 
    // object properties
    public $CenterId;
    public $County;
    public $SubCounty;
    public $CenterName;
    public $LocationLat;
    public $LocationLong;
    public $fullname;
    public $Status;
    

        // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
    public function readAll(){
            $common = new Common();
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

            $sql = "SELECT * FROM `vw_centers`";
                $stmt = $this->conn->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetchAll(PDO::FETCH_ASSOC);

                return $row;
    }
    public function readOne(){
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $sql = "SELECT * FROM `vw_centers` WHERE CenterId = ?";
        try{
            $stmt = $this->conn->prepare($sql);
            $stmt->bindParam(1, $this->CohortId);
            $stmt->execute();
            $num = $stmt->rowCount();
            if($num>0){      
                $row = $stmt->fetch(PDO::FETCH_ASSOC);   
                return $row;      
            } 
        }catch(Exception $ex){
            echo $ex;
        }
           
}
    public function insertOne(){
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $insertedRId  = 0;
        $query = "INSERT INTO `vs_centers`( `County`, `SubCounty`, `CenterName`,  `Efid`, `LocationLong`, `LocationLat`, `Status`)
		 VALUES (?,?,?,?,?,?,?)";
        try {
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $this->County);
            $stmt->bindParam(2, $this->SubCounty);
            $stmt->bindParam(3, $this->CenterName);
            $stmt->bindParam(4, $this->Efid);
            $stmt->bindParam(5, $this->LocationLong);
            $stmt->bindParam(6, $this->LocationLat);
            $stmt->bindParam(7, $this->Status);
            $stmt->execute();
            $insertedRId = $this->conn->lastInsertId();

        } catch (Exception $ex) {
            echo $ex ;
            var_dump($stmt);

        }
        return $insertedRId;
    }
    public function updateCenter(){
        $updated = false;
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $query = "UPDATE `vs_centers` SET `County`=?,`SubCounty`= ?,
		`CenterName`=?,`Efid`=?,`LocationLong`=?,`LocationLat`=?,`Status`= ?
		 WHERE CenterId = ?";
        try {
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $this->County);
            $stmt->bindParam(2, $this->SubCounty);
            $stmt->bindParam(3, $this->CenterName);
            $stmt->bindParam(4, $this->Efid);
			$stmt->bindParam(5, $this->LocationLong);
			$stmt->bindParam(6, $this->LocationLat);
			$stmt->bindParam(7, $this->Status);
			$stmt->bindParam(8, $this->CenterId);

            $stmt->execute();
            $updated = true;
        } catch (Exception $ex) {
            echo $ex;
        }
        return $updated;
    }
	
	public function deleteCenter($CenterId){
        $deleted = false;
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $query = "UPDATE `vs_centers` SET `isDeleted` = true
		 WHERE CenterId = ".$CenterId;
        try {
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            $deleted = true;
        } catch (Exception $ex) {
            echo $ex;
        }
        return $deleted;
    }
    
    
    
}
?>