<?php
$PageName="Centers";
$TooltipRequired=1;
$SearchRequired=1;
$FormRequired=1;
include("../../../Include.php");
include("../model/Centers.php");
include("../../config/database.php");
IsLoggedIn();
include("../../../Template/HTML.php");
?>    

<?php
include("../../../Template/Header.php");
?>

<?php
include("../../../Template/Sidebar.php");
?>

<div id="content" class="clearfix">
            <div class="contentwrapper">
			<?php $BreadCumb="Manage Centers"; BreadCumb($BreadCumb); ?>
            
				<?php DisplayNotification();?>

			<?php
             $database = new Database();
             $center = new Center($database->getConnection());
             $centers=$center->readAll();
			?>
                <div class="row-fluid">
                    <div class="span12">
                        <div class="box chart gradient">
                            <div class="title">
                             
                                <a href="#" class="minimize">Minimize</a>
                            </div>
                            </div>
					</div>
				</div>
					
                <div class="row-fluid">				
					<div class="span12">
						<div class="box gradient">
						<a href="Create" class="create-contact">Create Center</a>							<!-- <div class="content clearfix noPad"> -->
							<table id="centers" cellpadding="0" cellspacing="0" border="0" class="responsive dynamicTable display table table-bordered" width="100%">
								<thead>
									<tr>
										<td>#</td>
										<td>Center Name</td>
										<td>County</td>
										<td>Subcounty</td>
										<td>Ef Incharge</td>
										<td>Status</td>
										<td></td>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($centers as $center): ?>
									<tr>
										<td><?=$center['CenterId']?></td>
										<td><?=$center['CenterName']?></td>
										<td><?=$center['County']?></td>
										<td><?=$center['SubCounty']?></td>
										<td><?=$center['fullname']?></td>
										<td><?=$center['Status']?></td>
										<td class="actions">
											<a href="Update/<?=$center['CenterId']?>" class="edit"><i class="fas fa-pen fa-xs"></i></a>
											<a href="delete.php?id=<?=$contact['id']?>" class="trash"><i class="fas fa-trash fa-xs"></i></a>
										</td>
									</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
							<!-- </div> -->
						</div>
					</div>
                </div>
            </div>
        </div>
		
        <script type="text/javascript">
	$(document).ready(function() {
	
		$('#centers').dataTable({
			"sPaginationType": "two_button",
			"bJQueryUI": false,
			"bAutoWidth": false,
			"bLengthChange": false,  
			"bProcessing": true,
			"bDeferRender": true,
			"fnInitComplete": function(oSettings, json) {
			  $('.dataTables_filter>label>input').attr('id', 'search');
			}
		});
	
		$("#StaffPosition").select2();
		if($('#StaffDOJ').length) {
		$('#StaffDOJ').datepicker({ yearRange: "-100:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
		$("input, textarea, select").not('.nostyle').uniform();
		$('#StaffPosition').select2({placeholder: "Select"});
		$("#ManageStaff").validate({
			ignore: 'input[type="hidden"]',
			rules: {
				StaffPosition: {
					required: true,
				},
				StaffName: {
					required: true,
				},
				StaffMobile: {
					required: true,
					//remote: "RemoteValidation?Action=MobileValidation&Id=StaffMobile",
				},
				StaffDOJ: {
					required: true,
				}
			},
			messages: {
				StaffPosition: {
					required: "Please select this!!",
				},
				StaffName: {
					required: "Please enter this!!",
				},
				StaffMobile: {
					required: "Please enter this!!",
					//remote: jQuery.format("<?php echo $MOBILENUMBERDIGIT; ?> Digit Mobile number!!")
				},
				StaffDOJ: {
					required: "Please enter this!!",
				}
			}   
		});  
		$(function() {
			var baseURL = 'StaffAjaxTab';
			$('#StaffProfile').load(baseURL+'?Action=StaffProfile&Id=<?php echo $GetStaffId; ?>', function() {
				$('#myTabs').tab();
			});    
			$('#myTabs').bind('show', function(e) {    
			   var pattern=/#.+/gi
			   var contentID = e.target.toString().match(pattern)[0];
				$(contentID).load(baseURL+contentID.replace('#','?Id=<?php echo $GetStaffId; ?>&Action='), function(){
					$('#myTabs').tab();
				});
			});
		});
                
                //delete
                
                $('.deletestaff').live("click",function(e)
		{
                    e.preventDefault();
			if (confirm("Are you sure you want to delete?"))
			{
				var id = $(this).attr('id');
			
				$.ajax(
				{
				   type: "POST",
				   url: "DeleteStaff.php",
				   data: { StaffId: id},
				   cache: false,

				   success: function()
				   {
						window.location.reload();
				   },
				   error: function(data)
				   {
                                       alert(data);
				   }
				 });                
			}
		});
                
	});
</script>
<?php
include("Template/Footer.php");
?>