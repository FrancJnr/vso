<?php
$PageName="Centers";
$TooltipRequired=1;
$SearchRequired=1;
$FormRequired=1;
include("../../../Include.php");
include("../model/Centers.php");
include("../../config/database.php");
IsLoggedIn();
include("../../../Template/HTML.php");
?>    

<?php
include("../../../Template/Header.php");
?>

<?php
include("../../../Template/Sidebar.php");

?>

<?php
  $database = new Database();
  $center = new Center($database->getConnection());

$msg = '';
// Check if the contact id exists, for example update.php?id=1 will get the contact with the id of 1
if (isset($_GET['CenterId'])) {
    if (!empty($_POST)) {
        $id = isset($_POST['CenterId']) ? $_POST['CenterId'] : NULL;
        $County = isset($_POST['County']) ? $_POST['County'] : 'Please select a county';
        $SubCounty = isset($_POST['SubCounty']) ? $_POST['SubCounty'] : 'Please select a subcounty';
        $CenterName = isset($_POST['CenterName']) ? $_POST['CenterName'] : 'Please add Center name';
        $EF = isset($_POST['EF']) ? $_POST['EF'] : 'Please Select an Ef for the center';
        $center->CenterId = isset($_GET['CenterId'])? $_GET['CenterId'] : NULL;
        $center->insertOne();
        $msg = 'Updated Successfully!';

    }else{
        $center->CenterId = isset($_GET['CenterId'])? $_GET['CenterId'] : NULL;
        $center->readOne();
    }
    
} else {
    exit('No ID specified!');
}
?>
    <div id="content" class="clearfix">
            <div class="contentwrapper">
			<?php $BreadCumb="Update a catch up center"; BreadCumb($BreadCumb); ?>
            
            <?php if ($msg): ?>
            <p><?=$msg?></p>
            <?php endif; ?>

			<?php
             $database = new Database();
             $center = new Center($database->getConnection());
             $centers=$center->readAll();
			?>	
       	
                            <div class="row-fluid">				
                                <div class="span8">
                            <form class="form-horizontal"  name="AddCenter" id="AddCenter" method="Post">
                                    <div class="form-row row-fluid">
                                        <div class="span12">
                                            <div class="row-fluid">
                                            <label class="form-label span4" for="County">County</label> 
                                            <div class="span8 controls sel">   
                                                    <select tabindex="303" class="nostyle" name="County" id="County" value="<?=$centers['County']?> style="width:100%;">
                                                    <option></option>
                                                    <?php 
                                                            foreach(ListCounties() as $county){
                                                            echo "<option value=\"$county\">$county</option>" ;                              
                                                            }
                                                    ?>
                                                    </select>
                                                </div> 
                                            </div>
                                        </div> 
                                    </div>
                                    <div class="form-row row-fluid">
                                        <div class="span12">
                                            <div class="row-fluid">
                                            <label class="form-label span4" for="SubCounty">Sub County</label> 
                                            <div class="span8 controls sel">   
                                                    <select tabindex="303" class="nostyle" name="SubCounty" value="<?=$centers['SubCounty']?>  id="SubCounty" style="width:100%;">
                                                    <option></option>
                                                    <?php 
                                                            foreach($counties as $county){
                                                            echo "<option value=\"$county\">$county</option>" ;                              
                                                            }                              

                                                    ?>
                                                    </select>
                                                </div> 
                                            </div>
                                        </div> 
                                    </div>
                                    <div class="form-row row-fluid">
                                        <div class="span12">
                                            <div class="row-fluid">
                                                <label class="form-label span4" for="CenterName">Center Name</label>
                                                <input class="span8" tabindex="2" value="<?=$centers['CenterName']?>  id="CenterName" type="text" name="CenterName" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-row row-fluid">
                                        <div class="span12">
                                            <div class="row-fluid">
                                            <label class="form-label span4" for="EF">EF </label> 
                                                <div class="span8 controls sel">   
                                                <select tabindex="303" class="nostyle" value="<?=$centers['EF']?> name="EF" id="EF" style="width:100%;">
                                                <option></option>
                                                <?php echo ListEFs() ?>
                                                </select>
                                                </div> 
                                            </div>
                                        </div> 
                                    </div>

                                    <input style="background-color: #4CAF50; border: none; color: white; padding: 16px 32px; text-decoration: none; margin: 4px 2px;cursor: pointer;" type="submit" value="Create">                              
                              </form>
                    
                        </div>
                        <div class="row-fluid">				
					<div class="span12">
						<div class="box gradient">
							<table id="centers" cellpadding="0" cellspacing="0" border="0" class="responsive dynamicTable display table table-bordered" width="100%">
								<thead>
									<tr>
										<td>#</td>
										<td>Center Name</td>
										<td>County</td>
										<td>Subcounty</td>
										<td>Ef Incharge</td>
										<td>Status</td>
										<td></td>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($centers as $center): ?>
									<tr>
										<td><?=$center['CenterId']?></td>
										<td><?=$center['CenterName']?></td>
										<td><?=$center['County']?></td>
										<td><?=$center['SubCounty']?></td>
										<td><?=$center['fullname']?></td>
										<td><?=$center['Status']?></td>
										<td class="actions">
											<a href="update.php?id=<?=$contact['id']?>" class="edit"><i class="fas fa-pen fa-xs"></i></a>
											<a href="delete.php?id=<?=$contact['id']?>" class="trash"><i class="fas fa-trash fa-xs"></i></a>
										</td>
									</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
							<!-- </div> -->
						</div>
					</div>
                </div>

				
					</div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
	$(document).ready(function() {
	
		$('#centers').dataTable({
			"sPaginationType": "two_button",
			"bJQueryUI": false,
			"bAutoWidth": false,
			"bLengthChange": false,  
			"bProcessing": true,
			"bDeferRender": true,
			"fnInitComplete": function(oSettings, json) {
			  $('.dataTables_filter>label>input').attr('id', 'search');
			}
		});
	
		$("#StaffPosition").select2();
		if($('#StaffDOJ').length) {
		$('#StaffDOJ').datepicker({ yearRange: "-100:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
		$("input, textarea, select").not('.nostyle').uniform();
		$('#StaffPosition').select2({placeholder: "Select"});
		$("#ManageStaff").validate({
			ignore: 'input[type="hidden"]',
			rules: {
				StaffPosition: {
					required: true,
				},
				StaffName: {
					required: true,
				},
				StaffMobile: {
					required: true,
					//remote: "RemoteValidation?Action=MobileValidation&Id=StaffMobile",
				},
				StaffDOJ: {
					required: true,
				}
			},
			messages: {
				StaffPosition: {
					required: "Please select this!!",
				},
				StaffName: {
					required: "Please enter this!!",
				},
				StaffMobile: {
					required: "Please enter this!!",
					//remote: jQuery.format("<?php echo $MOBILENUMBERDIGIT; ?> Digit Mobile number!!")
				},
				StaffDOJ: {
					required: "Please enter this!!",
				}
			}   
		});  
		$(function() {
			var baseURL = 'StaffAjaxTab';
			$('#StaffProfile').load(baseURL+'?Action=StaffProfile&Id=<?php echo $GetStaffId; ?>', function() {
				$('#myTabs').tab();
			});    
			$('#myTabs').bind('show', function(e) {    
			   var pattern=/#.+/gi
			   var contentID = e.target.toString().match(pattern)[0];
				$(contentID).load(baseURL+contentID.replace('#','?Id=<?php echo $GetStaffId; ?>&Action='), function(){
					$('#myTabs').tab();
				});
			});
		});
                
                //delete
                
                $('.deletestaff').live("click",function(e)
		{
                    e.preventDefault();
			if (confirm("Are you sure you want to delete?"))
			{
				var id = $(this).attr('id');
			
				$.ajax(
				{
				   type: "POST",
				   url: "DeleteStaff.php",
				   data: { StaffId: id},
				   cache: false,

				   success: function()
				   {
						window.location.reload();
				   },
				   error: function(data)
				   {
                                       alert(data);
				   }
				 });                
			}
		});
                
	});
</script>
<?php
include("Template/Footer.php");
?>
		