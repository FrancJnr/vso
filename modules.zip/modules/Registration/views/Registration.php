<?php
$PageName="Registration";
$TooltipRequired=1;
$SearchRequired=1;
$FormRequired=1;
$TableRequired=1;
include("../../../Include.php");
include("../model/Registration.php");
include("../../config/database.php");
IsLoggedIn();
include("../../../Template/HTML.php");
?>    

<?php
include("../../../Template/Header.php");
?>

<?php
include("../../../Template/Sidebar.php");
?>

        <div id="content" class="clearfix">
            <div class="contentwrapper">
			<?php $BreadCumb="Learner Registration"; BreadCumb($BreadCumb); ?>
				
				<?php DisplayNotification(); ?>

			<?php
			 $db = new Database();
			 $reg = new Registration($db->getConnection());
			 if(isset($_POST['Submit'])){
			 $OOSG_CODE=isset($_POST['OOSG_CODE']) ? $_POST['OOSG_CODE'] : '';
			 $GirlName=isset($_POST['GirlName']) ? $_POST['GirlName'] : '';
			 $CenterId=isset($_POST['CenterId']) ? $_POST['CenterId'] : '';
			 $DOB=isset($_POST['DOB']) ? $_POST['DOB'] : '';
			 $LanguageSpoken=isset($_POST['LanguageSpoken']) ? $_POST['LanguageSpoken'] : '';
			 $HouseHeadName=isset($_POST['HouseHeadName']) ? $_POST['HouseHeadName'] : '';
			 $HouseHeadSex=isset($_POST['HouseHeadSex']) ? $_POST['HouseHeadSex'] : '';
			 $EF=isset($_POST['EF']) ? $_POST['EF'] : '';
			 $HouseHeadSpouseName=isset($_POST['HouseHeadSpouseName']) ? $_POST['HouseHeadSpouseName'] : '';
			 $GuardianContact=isset($_POST['GuardianContact']) ? $_POST['GuardianContact'] : '';
			 $GuardianOcupation=isset($_POST['GuardianOcupation']) ? $_POST['GuardianOcupation'] : '';
				echo($OOSG_CODE." ".$GirlName." ".$CenterName);
			 if($OOSG_CODE==null || $GirlName==null || $CenterId ==null){
			 	echo "Ensure all required fields are populated";
			 }else{
			 
			 	$reg->OOSG_CODE = $OOSG_CODE;
				$reg->GirlName = $GirlName;
				$reg->Efid = $EF;
			 	$reg->CenterId = $CenterId;
			 	$reg->Dob = $DOB;
			 	$reg->LanguageSpoken = $LanguageSpoken;
			 	$reg->HouseHeadName = $HouseHeadName;
			 	$reg->HouseHeadSex = $HouseHeadSex;
				$reg->HouseHeadSpouseName = $HouseHeadSpouseName;
				$reg->GuardianContact = $GuardianContact;
				$reg->GuardianOcupation = $GuardianOcupation;

			 	$reg->insertOne();

			 }
			}
		

			 $reg->readAll();
                                        
			 ?>	
					
                <div class="row-fluid">
                    <div class="span4">
						<form class="form-horizontal" action="ActionDelete" name="DeleteStudentRegistration" id="DeleteStudentRegistration" method="Post">
							<div id="DeleteStudentRegistration"></div>
						</form>
                        <div class="box chart gradient">
                            <div class="title">
                                <h4>
                                    <span>Registration</span>
                                </h4>
                                <a href="#" class="minimize">Minimize</a>
                            </div>
                            <div class="content" style="padding:5px;">
								<form class="form-horizontal"  name="Registration" id="Registration" method="Post">
							
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="OOSG_CODE">OOSG_CODE</label>
												<input class="span8" tabindex="1" id="OOSG_CODE" type="text" name="OOSG_CODE" value="" />
											</div>
										</div>
									</div>
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="GirlName">Girl's Name</label>
												<input class="span8" tabindex="2" id="GirlName" type="text" name="GirlName" value="" />
											</div>
										</div>
									</div>
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="CenterName">Catch Up center name</label>
												<select tabindex="1" name="CenterId" id="CenterId" class="nostyle" style="width:50%;" >
													<option></option>
													<?php echo ListCachUpCenters(); ?>
												</select>
											</div>
										</div>
									</div>
						
                                    <div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="DOB">Date of Birth</label>
												<input class="span8" readonly tabindex="11" id="DOB" type="text" name="DOB" value="" />
											</div>
										</div>
									</div>
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="LanguageSpoken">Language Spoken</label>
												<input class="span8" tabindex="2" id="LanguageSpoken" type="text" name="LanguageSpoken" value="" />
											</div>
										</div>
									</div>
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="HouseHeadName">House Head Name</label>
												<input class="span8" tabindex="2" id="HouseHeadName" type="text" name="HouseHeadName" value="" />
											</div>
										</div>
									</div> 
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="HouseHeadSex">Sex of the Household head</label>
												<select tabindex="1" name="HouseHeadSex" id="HouseHeadSex" class="nostyle" style="width:50%;" >
													<option></option>
													<?php echo ListGender(); ?>
												</select>
											</div>
										</div>
									</div> 
									 <div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
											<label class="form-label span4" for="EF">EF </label> 
												<div class="span8 controls sel">   
												<select tabindex="303" class="nostyle" name="EF" id="EF" style="width:100%;">
												<option></option>
												<?php echo ListEfs(); ?>
												</select>
												</div> 
											</div>
										</div> 
									</div>
  
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="HouseHeadSpouseName">House Head Spouse Name</label>
												<input class="span8" tabindex="2" id="HouseHeadSpouseName" type="text" name="HouseHeadSpouseName" value="" />
											</div>
										</div>
									</div> 
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="GuardianContact">Contacts of Parents/Guardians/ Spouse</label>
												<input class="span8" tabindex="2" id="GuardianContact" type="text" name="GuardianContact" value="" />
											</div>
										</div>
									</div>
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="GuardianOcupation">Occupation of the girl's Parents/Guardians/ Spouse</label>
												<input class="span8" tabindex="2" id="GuardianOcupation" type="text" name="GuardianOcupation" value="" />
											</div>
										</div>
									</div> 
									                                                 
										<?php $ButtonContent="Save"; ActionButton($ButtonContent,7,"Submit"); ?>
								</form>
                            </div>
                        </div>
                    </div>					
					<div class="span8">
						<div class="box gradient">
							<div class="title">
								<h4>
									<span>Registration List</span>
									<?php if($count3>0) { ?>
									<div class="PrintClass">
										<form method=post action=Print target=_blank>
										<input type="hidden" name="Action" value="Print" readonly>
										<input type="hidden" name="PrintCategory" value="PrintCategory" readonly>
										<input type="hidden" name="SessionName" value="PrintRegistrationList" readonly>
										<input type="hidden" name="HeadingName" value="PrintRegistrationHeading" readonly>
										<button class="icomoon-icon-printer-2 tip" title="Print Registration List"></button>
										</form>
									</div>
									<?php } ?>
								</h4>
							<a href="#" class="minimize">Minimize</a>
							</div>
							<div class="content clearfix noPad">
								<?php
								$Print1="<table id=\"RegistrationTable\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" class=\"responsive dynamicTable display table table-bordered\" width=\"100%\">
									<thead>
										<tr>
		
											<th>Name</th>
											<th>#OOSG_CODE</th>
											<th>Catch Up Center</th>
											<th>Date Of Birth</th>
											<th>Cohort</th>
											<th>Assigned EF</th>
											<th>Guardian Contact</th>
											<th>Created On</th>
											
						                  ";
											echo $Print1;
											// echo "<th><span class=\"icomoon-icon-cancel tip\" title=\"Delete\"></span></th>";
										$Print2="</tr>
									</thead>
									<tbody>";
									echo $Print2;
									$Print4="</tbody>
								</table>";
								echo $Print4;
								$PrintRegistrationList="$Print1 $Print2 $Print3 $Print4";
								$_SESSION['PrintRegistrationList']=$PrintRegistrationList;
								$PrintHeading="Showing List of Registration";
								$_SESSION['PrintRegistrationHeading']=$PrintHeading;
								$_SESSION['PrintCategory']="Registration";
								?>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
		
<script type="text/javascript">
	$(document).ready(function() {
	
		$('#RegistrationTable').dataTable({
			"sPaginationType": "two_button",
			"bJQueryUI": false,
			"bAutoWidth": false,
			"bLengthChange": false,  
			"bProcessing": true,
			"bDeferRender": true,
			"sAjaxSource": "plugins/Data/data1.txt",
			"fnInitComplete": function(oSettings, json) {
			  $('.dataTables_filter>label>input').attr('id', 'search');
                          
      
			}
		});
                
                //delete student
                 
                      $('.deletereg').live('click',function(e){
        e.preventDefault();
        $ListRegistrationId=$(this).attr("id");
        $Random=$("#RandomNumber").val();
        $message=confirm('Are you sure you want to proceed?');
     if($message==true){
        var data={"RegistrationId":$ListRegistrationId,"RandomNumber":$Random}
         var jqxhr = $.post("DeleteStudent.php",data, function() {
 
})
  .done(function(message) {
 alert(message);
 window.location.reload();
  })
  .fail(function() {
    alert( "error deleting" );
  }) 
     }
    else{
        return false;
    }
        
      // showdetail($ListRegistrationId,'DeleteStudentRegistration','DeleteStudentRegistration');
      
        })
                
	
		$("#Class").select2();
                	$("#boardingday").select2();
		$('#Class').select2({placeholder: "Select"});
		$("#Gender").select2();
		$('#Gender').select2({placeholder: "Select"});
                $("#year").select2();
		$('#year').select2({placeholder: "Select"});
                $("#term").select2();
		$('#term').select2({placeholder: "Select"});
		if($('#DOR').length) {
		$('#DOR').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
                if($('#DOB').length) {
		$('#DOB').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
                if($('#UpdateDOA').length) {
		$('#UpdateDOA').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
                if($('#UpdateDOR').length) {
	$("#UpdateDOR").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
}

	$("#UpdateDOTest").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });

	$("#UpdateDORecords").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
        $("#UpdateDateDeposit").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });

                
		$("input, textarea, select").not('.nostyle').uniform();
		$("#StudentRegistration").validate({
			ignore: 'input[type="hidden"]',
			rules: {
				StudentName: {
					required: true,
				},
				FatherName: {
					//required: true,
				},
				MotherName: {
					//required: true,
				},
				Class: {
					required: true,
				},
				DOR: {
					// required: true,
				},
				MotherMobile: {
					//required: true,
					//remote: "RemoteValidation?Action=MobileValidation&Id=Mobile"
				}
			},
			messages: {
				StudentName: {
					required: "Please enter this!!",
				},
				FatherName: {
					// required: "Please enter this!!",
				},
				MotherName: {
					// required: "Please enter this!!",
				},
				Class: {
					required: "Please select this!!",
				},
				DOR: {
					// required: "Please enter this!!",
				},
				MotherMobile: {
					// required: "Please enter this!!",
					remote: jQuery.format("<?php echo $MOBILENUMBERDIGIT; ?> Digit Mobile number!!")
				}
			}   
		});
	});
	$("#DeleteStudentRegistration").validate({
		rules: {
			Password: {
				required: true,
			}
		},
		messages: {
			Password: {
				required: "Please enter this!!",
			}
		}   
	});
	
	$(document).ready(function() {      
		$(function() {
			var baseURL = 'StudentAjaxTab';
			$('#StudentProfile').load(baseURL+'?Action=StudentProfile&Id=<?php echo $GetRegistrationId; ?>', function() {
				$('#myTabs').tab();
			});    
			$('#myTabs').bind('show', function(e) {    
			   var pattern=/#.+/gi
			   var contentID = e.target.toString().match(pattern)[0];
				$(contentID).load(baseURL+contentID.replace('#','?Id=<?php echo $GetRegistrationId; ?>&Action='), function(){
					$('#myTabs').tab();
				});
			});
		});
	
        
        
        function showdetail($regid,$action1,$action2){
        
        alert($regid+" "+$action1+" "+$action2);
        }
        
        
	});
</script>
<?php
include("Template/Footer.php");
?>