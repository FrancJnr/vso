<?php
include("../../modules/common/common.php");
include("../config/database.php");
class DashboardReport{
  
    // database connection and table name
    private $conn;
 
    // object properties
    public $CohortId;
    public $CohortTitle;
    
    
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
       
    }

    function noOfStudentsPerCohort(){
        echo "Here";
        $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            // select all query
        try {
            $sql = "SELECT COUNT(OOSG_CODE), CohortTitle
            FROM vs_students
            INNER JOIN vs_cohorts ON vs_students.CohortId = vs_cohorts.CohortId
            GROUP BY CohortTitle";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute();
            $num = $stmt->rowCount();
            
            if($num>0){
                $data_points=array();
                $points = array();
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                    $data_points[]=array(
                            'label'=>$row['CohortTitle'], 'y'=>20              
                        );                  
                }
           
                
                return $data_points;
            }
            
        } catch (Exception $ex) {
            var_dump($ex->getMessage());
            return array('resp_msg'=>'There was an error while fetching the records');
        }
    
}


    
}
?>