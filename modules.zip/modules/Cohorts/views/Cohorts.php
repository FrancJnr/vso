<?php
$PageName="Cohorts";
$TooltipRequired=1;
$SearchRequired=1;
$FormRequired=1;
$TableRequired=1;
include("../../../Include.php");
include("../model/Cohorts.php");
include("../../config/database.php");
IsLoggedIn();
include("../../../Template/HTML.php");
?>    

<?php
include("../../../Template/Header.php");
?>

<?php
include("../../../Template/Sidebar.php");
?>

        <div id="content" class="clearfix">
            <div class="contentwrapper">
			<?php $BreadCumb="Cohorts"; BreadCumb($BreadCumb); ?>
				
				<?php DisplayNotification(); ?>

			<?php
			 $db = new Database();
			 $cohort = new Cohorts($db->getConnection());

			 if(isset($_POST['Submit'])){
			 $CohortTitle=isset($_POST['CohortTitle']) ? $_POST['CohortTitle'] : '';
			 $StartDate=isset($_POST['StartDate']) ? $_POST['StartDate'] : '';
			 $EndDate=isset($_POST['EndDate']) ? $_POST['EndDate'] : '';

			 $IsActive=isset($_POST['IsActive']) ? $_POST['IsActive'] : 0;
			 $Description=isset($_POST['Description']) ? $_POST['Description'] : '';
	
			 if($CohortTitle==null || $StartDate==null || $EndDate ==null ){
			 	echo "Ensure all required fields are populated";
			 }else{
			 
			 	$cohort->CohortTitle = $CohortTitle;
			 	$cohort->StartDate = $StartDate;
			 	$cohort->EndDate = $EndDate;
			 	$cohort->IsActive = $IsActive;
			 	$cohort->Description = $Description;
			 
			 	$cohort->insertOne();

			 }
			}
			 $cohort->readAll();
			                                      
            echo $_POST['RegistrationId'];                       
			 ?>	
					
                <div class="row-fluid">
                    <div class="span4">
						<form class="form-horizontal" action="ActionDelete" name="DeleteStudentRegistration" id="DeleteStudentRegistration" method="Post">
							<div id="DeleteStudentRegistration"></div>
						</form>
                        <div class="box chart gradient">
                            <div class="title">
                                <h4>
                                    <span>Create Cohort</span>
                                </h4>
                                <a href="#" class="minimize">Minimize</a>
                            </div>
                            <div class="content" style="padding:5px;">
								<form class="form-horizontal"  name="cohort" id="cohort" method="Post">
							
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="CohortTitle">Cohort Name</label>
												<input class="span8" tabindex="1" id="CohortTitle" type="text" name="CohortTitle" value="" />
											</div>
										</div>
									</div>
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="StartDate">Starts On</label>
												<input class="span8" readonly tabindex="11" id="StartDate" type="text" name="StartDate" value="" />
											</div>
										</div>
									</div>
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="EndDate">Ends On</label>
												<input class="span8" readonly tabindex="11" id="EndDate" type="text" name="EndDate" value="" />
											</div>
										</div>
									</div>
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="IsActive">Active</label>
												<input class="span8" tabindex="2" id="IsActive" type="checkbox" name="IsActive" value="" />
											</div>
										</div>
									</div>
									<div class="form-row row-fluid">
										<div class="span12">
											<div class="row-fluid">
												<label class="form-label span4" for="Description">Description</label>
												<input class="span8" tabindex="2" id="Description" type="text area" name="Description" value="" />
											</div>
										</div>
									</div>
									                                                   
										<?php $ButtonContent="Save"; ActionButton($ButtonContent,7,"Submit"); ?>
								</form>
                            </div>
                        </div>
                    </div>					
					<div class="span8">
						<div class="box gradient">
							<div class="title">
								<h4>
									<span>Cohort List</span>
								</h4>
							<a href="#" class="minimize">Minimize</a>
							</div>
							<div class="content clearfix noPad">
								<?php
								$Print1="<table id=\"CohortTable\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" class=\"responsive dynamicTable display table table-bordered\" width=\"100%\">
									<thead>
										<tr>
											<th>#ID</th>
											<th>Cohort Name</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>Active</th>
											<th>Actions</th>
										";
											echo $Print1;
											// echo "<th><span class=\"icomoon-icon-cancel tip\" title=\"Delete\"></span></th>";
										$Print2="</tr>
									</thead>
									<tbody>";
									echo $Print2;
									$Print4="</tbody>
								</table>";
								echo $Print4;
							
								?>
							</div>
						</div>
					</div>
                </div>
            </div>
        </div>
		
<script type="text/javascript">
	$(document).ready(function() {
	
		$('#CohortTable').dataTable({
			"sPaginationType": "two_button",
			"bJQueryUI": false,
			"bAutoWidth": false,
			"bLengthChange": false,  
			"bProcessing": true,
			"bDeferRender": true,
			"sAjaxSource": "plugins/Data/data8.txt",
			"fnInitComplete": function(oSettings, json) {
			  $('.dataTables_filter>label>input').attr('id', 'search');
                          
      
			}
		});
                
        //delete student
                 
        $('.delete').live('click',function(e){
         e.preventDefault();
			if (confirm("Are you sure you want to delete?"))
			{
				var id = $(this).attr('id');
			
				$.ajax(
				{
				   type: "POST",
				   url: "DeleteStudent.php",
				   data: { RegistrationId: id},
				   cache: false,

				   success: function()
				   {
					alert("Record deleted");
				   },
				   error: function(data)
				   {
                     alert(data);
				   }
				 });                
			}
		});
        
        
      // showdetail($ListRegistrationId,'DeleteStudentRegistration','DeleteStudentRegistration');
             
	
		$("#Class").select2();
                	$("#boardingday").select2();
		$('#Class').select2({placeholder: "Select"});
		$("#Gender").select2();
		$('#Gender').select2({placeholder: "Select"});
                $("#year").select2();
		$('#year').select2({placeholder: "Select"});
                $("#term").select2();
		$('#term').select2({placeholder: "Select"});

		if($('#StartDate').length) {
		$('#StartDate').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
		if($('#EndDate').length) {
		$('#EndDate').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}

		if($('#DOR').length) {
		$('#DOR').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
        if($('#DOB').length) {
		$('#DOB').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
        if($('#UpdateDOA').length) {
		$('#UpdateDOA').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
         if($('#UpdateDOR').length) {
	    $("#UpdateDOR").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
}

	    ("#UpdateDOTest").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });

	    $("#UpdateDORecords").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
        $("#UpdateDateDeposit").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });

                
		$("input, textarea, select").not('.nostyle').uniform();
		$("#StudentRegistration").validate({
			ignore: 'input[type="hidden"]',
			rules: {
				StudentName: {
					required: true,
				},
				FatherName: {
					//required: true,
				},
				MotherName: {
					//required: true,
				},
				Class: {
					required: true,
				},
				DOR: {
					// required: true,
				},
				MotherMobile: {
					//required: true,
					//remote: "RemoteValidation?Action=MobileValidation&Id=Mobile"
				}
			},
			messages: {
				StudentName: {
					required: "Please enter this!!",
				},
				FatherName: {
					// required: "Please enter this!!",
				},
				MotherName: {
					// required: "Please enter this!!",
				},
				Class: {
					required: "Please select this!!",
				},
				DOR: {
					// required: "Please enter this!!",
				},
				MotherMobile: {
					// required: "Please enter this!!",
					remote: jQuery.format("<?php echo $MOBILENUMBERDIGIT; ?> Digit Mobile number!!")
				}
			}   
		});
	});
	$("#DeleteStudentRegistration").validate({
		rules: {
			Password: {
				required: true,
			}
		},
		messages: {
			Password: {
				required: "Please enter this!!",
			}
		}   
	});
	
	$(document).ready(function() {      
		$(function() {
			var baseURL = 'StudentAjaxTab';
			$('#StudentProfile').load(baseURL+'?Action=StudentProfile&Id=<?php echo $GetRegistrationId; ?>', function() {
				$('#myTabs').tab();
			});    
			$('#myTabs').bind('show', function(e) {    
			   var pattern=/#.+/gi
			   var contentID = e.target.toString().match(pattern)[0];
				$(contentID).load(baseURL+contentID.replace('#','?Id=<?php echo $GetRegistrationId; ?>&Action='), function(){
					$('#myTabs').tab();
				});
			});
		});
	
        
        
        function showdetail($regid,$action1,$action2){
        
        alert($regid+" "+$action1+" "+$action2);
        }
        
        
	});
</script>
<?php
include("Template/Footer.php");
?>