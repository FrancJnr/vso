<?php
$PageName="Students";
$TooltipRequired=1;
$SearchRequired=1;
$FormRequired=1;
$TableRequired=1;
include("../../../Include.php");
include("..//model/StudentProgress.php");
include("../../config/database.php");
IsLoggedIn();
include("../../../Template/HTML.php");
?>    

<?php
include("../../../Template/Header.php");
?>

<?php
include("../../../Template/Sidebar.php");
?>

    <div id="content" class="clearfix">
            <div class="contentwrapper">
			<?php $BreadCumb="Promotions"; BreadCumb($BreadCumb); ?>
				
				<?php DisplayNotification(); ?>

			<?php
			 $db = new Database();
			 $stdnt = new StudentProgress($db->getConnection());
			 $students = $stdnt->readAll(); 		                
			 ?>	
					
                    <div class="row-fluid">
                    <div class="span12">
                        <div class="box chart gradient">
                            <div class="title">
                                <h4>
                                    <span>Promotion Requests</span>
                                </h4>
                                <a href="#" class="minimize">Minimize</a>
                            </div>
                            <div class="content" style="padding-bottom:0;">
                                <div class="content clearfix noPad">
                                        <table id="NotAdmittedTable" cellpadding="0" cellspacing="0" border="0" class="responsive dynamicTable display table table-bordered" width="100%">
                                        <thead>
                                                <tr>
                                                    <td>#</td>
                                                    <td>OOSG_CODE</td>
                                                    <td>Girl Name</td>
                                                    <td>Center Name</td>
                                                    <td>Cohort</td>
                                                    <td>Created</td>
                                                    <td></td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php foreach ($students as $student): ?>
                                                <tr>
                                                    <td><?=$student['id']?></td>
                                                    <td><?=$student['name']?></td>
                                                    <td><?=$student['email']?></td>
                                                    <td><?=$student['phone']?></td>
                                                    <td><?=$student['title']?></td>
                                                    <td><?=$student['created']?></td>
                                                    <td class="actions">
                                                        <a href="update.php?id=<?=$contact['id']?>" class="edit"><i class="fas fa-pen fa-xs"></i></a>
                                                        <a href="delete.php?id=<?=$contact['id']?>" class="trash"><i class="fas fa-trash fa-xs"></i></a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                
                                </div>
                            </div>			
							</div>
					</div>
				</div>
            </div>
        </div>
		
<script type="text/javascript">
	$(document).ready(function() {
		$('#NotAdmittedTable').dataTable({
			"sPaginationType": "two_button",
			"bJQueryUI": false,
			"bAutoWidth": false,
			"bLengthChange": false,  
			"bProcessing": true,
			"bDeferRender": true,
			"sAjaxSource": "plugins/Data/data13.txt",
			"fnInitComplete": function(oSettings, json) {
			  $('.dataTables_filter>label>input').attr('id', 'search');
                          
      
			}
		});
	
		// $('#AdmittedTable').dataTable({
		// 	"sPaginationType": "two_button",
		// 	"bJQueryUI": false,
		// 	"bAutoWidth": false,
		// 	"bLengthChange": false,  
		// 	"bProcessing": true,
		// 	"bDeferRender": true,
		// 	"sAjaxSource": "plugins/Data/data1.txt",
		// 	"fnInitComplete": function(oSettings, json) {
		// 	  $('.dataTables_filter>label>input').attr('id', 'search');
                          
      
		// 	}
		// });
		
                
                //delete student
                 
        $('.deletereg').live('click',function(e){
        e.preventDefault();
        $ListRegistrationId=$(this).attr("id");
        $Random=$("#RandomNumber").val();
        $message=confirm('Are you sure you want to proceed?');
     if($message==true){
        var data={"RegistrationId":$ListRegistrationId,"RandomNumber":$Random}
         var jqxhr = $.post("DeleteStudent.php",data, function() {
 
})
  .done(function(message) {
 alert(message);
 window.location.reload();
  })
  .fail(function() {
    alert( "error deleting" );
  }) 
     }
    else{
        return false;
    }
        
      // showdetail($ListRegistrationId,'DeleteStudentRegistration','DeleteStudentRegistration');
      
        })
                
	
		$("#Class").select2();
                	$("#boardingday").select2();
		$('#Class').select2({placeholder: "Select"});
		$("#Gender").select2();
		$('#Gender').select2({placeholder: "Select"});
                $("#year").select2();
		$('#year').select2({placeholder: "Select"});
                $("#term").select2();
		$('#term').select2({placeholder: "Select"});
		if($('#DOR').length) {
		$('#DOR').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
                if($('#DOB').length) {
		$('#DOB').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
                if($('#UpdateDOA').length) {
		$('#UpdateDOA').datetimepicker({ yearRange: "-180:+0", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
		}
                if($('#UpdateDOR').length) {
	$("#UpdateDOR").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
}

	$("#UpdateDOTest").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });

	$("#UpdateDORecords").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });
        $("#UpdateDateDeposit").datetimepicker({ yearRange: "-10:+10", dateFormat: 'dd-mm-yy',changeMonth: true, changeYear: true });

                
		$("input, textarea, select").not('.nostyle').uniform();
		$("#StudentRegistration").validate({
			ignore: 'input[type="hidden"]',
			rules: {
				StudentName: {
					required: true,
				},
				FatherName: {
					//required: true,
				},
				MotherName: {
					//required: true,
				},
				Class: {
					required: true,
				},
				DOR: {
					// required: true,
				},
				MotherMobile: {
					//required: true,
					//remote: "RemoteValidation?Action=MobileValidation&Id=Mobile"
				}
			},
			messages: {
				StudentName: {
					required: "Please enter this!!",
				},
				FatherName: {
					// required: "Please enter this!!",
				},
				MotherName: {
					// required: "Please enter this!!",
				},
				Class: {
					required: "Please select this!!",
				},
				DOR: {
					// required: "Please enter this!!",
				},
				MotherMobile: {
					// required: "Please enter this!!",
					remote: jQuery.format("<?php echo $MOBILENUMBERDIGIT; ?> Digit Mobile number!!")
				}
			}   
		});
	});
	$("#DeleteStudentRegistration").validate({
		rules: {
			Password: {
				required: true,
			}
		},
		messages: {
			Password: {
				required: "Please enter this!!",
			}
		}   
	});
	
	$(document).ready(function() {      
		$(function() {
			var baseURL = 'StudentAjaxTab';
			$('#StudentProfile').load(baseURL+'?Action=StudentProfile&Id=<?php echo $GetRegistrationId; ?>', function() {
				$('#myTabs').tab();
			});    
			$('#myTabs').bind('show', function(e) {    
			   var pattern=/#.+/gi
			   var contentID = e.target.toString().match(pattern)[0];
				$(contentID).load(baseURL+contentID.replace('#','?Id=<?php echo $GetRegistrationId; ?>&Action='), function(){
					$('#myTabs').tab();
				});
			});
		});
	
        
        
        function showdetail($regid,$action1,$action2){
        
        alert($regid+" "+$action1+" "+$action2);
        }
        
        
	});
</script>
<?php
include("Template/Footer.php");
?>